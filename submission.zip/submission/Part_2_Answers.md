Q1: Choosing the Right Approach
You are tasked with identifying whether a product is missing its label on an assembly line. The products are visually similar except for the label.
Q: Would you use classification, detection, or segmentation? Why? What would be your fallback if the first approach doesn’t work?
Ans:I would start with object detection because the task involves identifying whether a label is present on a product, which requires localizing a specific region rather than classifying the entire image. Since the products are visually similar except for the label, simple image classification might struggle if the label occupies only a small part of the image. Detection allows the model to explicitly identify and localize the label area. If detection does not perform well, my fallback would be segmentation, especially if the label is small, partially occluded, or blends with the product surface. Segmentation would help precisely isolate the label region at the pixel level, improving robustness in complex visual conditions.

Q2: Debugging a Poorly Performing Model
You trained a model on 1000 images, but it performs poorly on new images from the factory.
Q: Design a small experiment or checklist to debug the issue. What would you test or visualize?
Ans:First, I would check for data distribution shift by comparing training images with new factory images to see if lighting, camera angles, or backgrounds differ. Next, I would visualize predictions on both training and new data to identify consistent failure patterns. I would also inspect label quality to ensure annotations are correct and consistent. Then, I would analyze per-class performance metrics to see if the model struggles more with certain categories. Finally, I would test simple augmentations or fine-tune on a small batch of new factory images to confirm whether the issue is generalization or dataset mismatch.

Q3: Accuracy vs Real Risk
Your model has 98% accuracy but still misses 1 out of 10 defective products.
Ans:Accuracy is not the right metric in this case because it does not reflect the cost of missing defective products. If the model misses 1 out of 10 defects, that indicates a high false negative rate, which could lead to safety or financial risks. Instead, I would focus on recall (sensitivity) for defective products, since missing defects is more critical than occasionally flagging a good product. I would also analyze the confusion matrix to understand the balance between false positives and false negatives. In safety-critical systems, optimizing recall or using metrics like F1-score or precision-recall curves is more appropriate than relying on overall accuracy.
Q: Is accuracy the right metric in this case? What would you look at instead and why?
Q4: Annotation Edge Cases
You’re labeling data, but many images contain blurry or partially visible objects.
Q: Should these be kept in the dataset? Why or why not? What trade-offs are you considering?

Ans:Yes, I would keep blurry or partially visible objects in the dataset because they reflect real-world conditions the model will encounter. Removing them may artificially improve training performance but reduce real-world robustness. However, I would ensure they are clearly and consistently labeled to avoid confusing the model. The trade-off is between cleaner training data and better generalization to difficult scenarios. Including such edge cases usually improves model resilience, especially in industrial environments where lighting and motion blur are common.
